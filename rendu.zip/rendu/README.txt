
# Run the code
In order to run the code, a train.csv and test.csv must be in a folder named dataset and located in the previous directory

numpy must be installed and all other python files must at the same level in a files folder

run the clean_csv.py to obtained new csv files without -999 values (and standardized)

run run.py to train the best found method (ridge regression) and produce a csv file for submission named submission.csv

## Specifications
All functions destined to clean and organized the dataset are in helpers module

All method functions required for the project are listed in utils_functions module

### tested on python 3.5.2